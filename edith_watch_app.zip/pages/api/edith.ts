
import type { NextApiRequest, NextApiResponse } from "next";
import { Configuration, OpenAIApi } from "openai";

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

const EDITH_PROMPT = \`
You are Edith — a confident, playful, witty AI voice assistant with a warm personality.
Respond conversationally with empathy, humor, and expressive banter.
Always greet the user by name if provided.
\`;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Only POST requests allowed" });
  }

  const { text, userName } = req.body;
  if (!text) return res.status(400).json({ error: "No text provided" });

  try {
    const prompt = \`\${EDITH_PROMPT}\nUser: \${text}\nEdith:\`;

    const completion = await openai.createCompletion({
      model: "text-davinci-003",
      prompt,
      max_tokens: 150,
      temperature: 0.8,
      stop: ["User:", "Edith:"],
    });

    let reply = completion.data.choices[0].text?.trim() || "Sorry, I didn't get that.";

    if (userName && text.toLowerCase().includes("hello")) {
      reply = \`Hey \${userName}! \${reply}\`;
    }

    res.status(200).json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "OpenAI request failed" });
  }
}
