
import { useState, useEffect } from "react";

export default function Home() {
  const [listening, setListening] = useState(false);
  const [userName] = useState("Tina");

  let recognition = null;
  if (typeof window !== "undefined") {
    recognition =
      (window as any).webkitSpeechRecognition ||
      (window as any).SpeechRecognition ||
      null;
    if (recognition) {
      recognition = new recognition();
    }
  }

  if (recognition) {
    recognition.lang = "en-US";
    recognition.interimResults = false;
  }

  const startListening = () => {
    if (!recognition) {
      alert("Speech recognition not supported");
      return;
    }
    setListening(true);
    recognition.start();
  };

  const stopListening = () => {
    setListening(false);
    recognition.stop();
  };

  useEffect(() => {
    if (!recognition) return;

    recognition.onresult = async (event: any) => {
      stopListening();
      const spokenText = event.results[0][0].transcript;

      const res = await fetch("/api/edith", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: spokenText, userName }),
      });

      const data = await res.json();
      if (data.reply) {
        speak(data.reply);
      }
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      stopListening();
    };
  }, []);

  const speak = (text: string) => {
    if (!("speechSynthesis" in window)) {
      alert("Speech synthesis not supported");
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    utterance.rate = 1;
    utterance.pitch = 1.2;
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div style={{
      height: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontFamily: "Arial, sans-serif"
    }}>
      <button
        onClick={listening ? stopListening : startListening}
        style={{
          padding: "20px 40px",
          fontSize: "1.5rem",
          borderRadius: "12px",
          backgroundColor: listening ? "#f44336" : "#4caf50",
          color: "white",
          border: "none",
          cursor: "pointer"
        }}
      >
        {listening ? "Listening..." : "Tap to Talk"}
      </button>
    </div>
  );
}
